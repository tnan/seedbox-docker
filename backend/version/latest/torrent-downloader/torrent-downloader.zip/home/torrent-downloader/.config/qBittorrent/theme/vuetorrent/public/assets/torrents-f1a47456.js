const t=[{name:"First torrent"},{name:"Second torrent"}];export{t as default};
